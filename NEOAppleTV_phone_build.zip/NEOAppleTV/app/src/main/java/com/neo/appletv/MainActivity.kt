package com.neo.appletv

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.KeyEvent
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val bg = Color.rgb(8, 12, 22)
    private val panel = Color.rgb(27, 34, 50)
    private val white = Color.WHITE
    private val apps = listOf(
        AppTile("YouTube", "▶", "com.google.android.youtube.tv"),
        AppTile("Кино", "◉", "ru.ivi.client"),
        AppTile("Браузер", "◎", "com.android.chrome"),
        AppTile("Игры", "✦", null),
        AppTile("Приложения", "▦", null),
        AppTile("Настройки", "⚙", "com.android.tv.settings")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        buildScreen()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(34), dp(22), dp(34), dp(22))
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(8, 13, 26), Color.rgb(22, 27, 48), Color.rgb(8, 12, 22))
            )
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(label("●", 27f, white, true))
        header.addView(space(18))
        header.addView(label("NEO", 25f, white, true))
        header.addView(space(20))
        header.addView(label("APPLE TV STYLE", 12f, Color.LTGRAY, false))
        val clock = label(now(), 17f, white, true)
        val clockParams = LinearLayout.LayoutParams(0, dp(42), 1f)
        clockParams.gravity = Gravity.RIGHT
        clock.gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
        header.addView(clock, clockParams)
        root.addView(header)

        root.addView(spaceVertical(24))
        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(30), dp(18), dp(30), dp(18))
            background = rounded(Color.rgb(38, 52, 79), 24)
        }
        hero.addView(label("ВАШ ТЕЛЕВИЗОР. ВАШИ ПРАВИЛА.", 13f, Color.rgb(190, 207, 235), true))
        hero.addView(spaceVertical(8))
        hero.addView(label("Добро пожаловать домой", 29f, white, true))
        hero.addView(spaceVertical(6))
        hero.addView(label("Выберите приложение с помощью пульта", 15f, Color.LTGRAY, false))
        root.addView(hero, LinearLayout.LayoutParams(-1, dp(150)))

        root.addView(spaceVertical(26))
        root.addView(label("Ваши приложения", 21f, white, true))
        root.addView(spaceVertical(14))

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        apps.forEachIndexed { index, app ->
            val tile = TextView(this).apply {
                text = "${app.symbol}\n\n${app.name}"
                textSize = 16f
                setTextColor(white)
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                gravity = Gravity.CENTER
                isFocusable = true
                isFocusableInTouchMode = true
                background = rounded(panel, 18)
                setPadding(dp(8), dp(8), dp(8), dp(8))
                foreground = null
                setOnFocusChangeListener { v, hasFocus ->
                    v.background = rounded(
                        if (hasFocus) Color.rgb(67, 105, 157) else panel,
                        18,
                        if (hasFocus) Color.rgb(178, 220, 255) else Color.rgb(55, 65, 85)
                    )
                    v.scaleX = if (hasFocus) 1.06f else 1f
                    v.scaleY = if (hasFocus) 1.06f else 1f
                }
                setOnClickListener { openApp(app) }
                contentDescription = app.name
            }
            val lp = LinearLayout.LayoutParams(0, dp(126), 1f)
            if (index > 0) lp.leftMargin = dp(12)
            row.addView(tile, lp)
        }
        root.addView(row)
        root.addView(spaceVertical(24))
        root.addView(label("Недавно использованные", 20f, white, true))
        root.addView(spaceVertical(10))
        root.addView(label("Здесь можно разместить любимые приложения и контент.", 14f, Color.LTGRAY, false))
        setContentView(root)
        row.getChildAt(0)?.requestFocus()
    }

    private fun openApp(tile: AppTile) {
        val pkg = tile.packageName
        if (pkg == null) {
            Toast.makeText(this, "Этот раздел можно настроить в следующей версии", Toast.LENGTH_SHORT).show()
            return
        }
        val launch = packageManager.getLaunchIntentForPackage(pkg)
        if (launch != null) startActivity(launch)
        else Toast.makeText(this, "Приложение «${tile.name}» не найдено на телевизоре", Toast.LENGTH_SHORT).show()
    }

    private fun now(): String =
        SimpleDateFormat("HH:mm  •  EEEE, d MMMM", Locale("ru")).format(Date())

    private fun label(text: String, size: Float, color: Int, bold: Boolean) =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.create("sans-serif", Typeface.BOLD)
            gravity = Gravity.CENTER_VERTICAL
        }

    private fun space(width: Int) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(dp(width), 1)
    }

    private fun spaceVertical(height: Int) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(height))
    }

    private fun rounded(color: Int, radius: Int, stroke: Int = Color.TRANSPARENT) =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
            if (stroke != Color.TRANSPARENT) setStroke(dp(2), stroke)
        }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    data class AppTile(val name: String, val symbol: String, val packageName: String?)
}
